package com.ra.base_spring_boot.security.principle;

import com.ra.base_spring_boot.model.Candidate;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ToString(exclude = "candidate")
public class MyUserDetails implements UserDetails {

    private Candidate candidate;
    private Collection<? extends GrantedAuthority> authorities;

    public Candidate getCandidate() {
        return this.candidate;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.authorities;
    }

    @Override
    public String getPassword() {
        return this.candidate.getPassword();
    }

    @Override
    public String getUsername() {
        return this.candidate.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return this.candidate.getIsOpen() != null && this.candidate.getIsOpen() == 1;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.candidate.getIsOpen() != null && this.candidate.getIsOpen() == 1;
    }
}
